const o="/assets/logo-c932cd97.png";export{o as l};
